# DecodeLabs Industrial Training Kit — Project 2

## Backend API Development

This project implements the requirements from Project 2: a simple backend API that handles application logic, accepts user input, validates basic data, and returns JSON responses.

### Technology
- Node.js
- Express.js
- CORS
- In-memory JavaScript data store

### API endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/` | API status and endpoint information |
| GET | `/api/users` | Get all users |
| GET | `/api/users/:id` | Get one user |
| POST | `/api/users` | Create a new user |

### POST request example

Send JSON to `/api/users`:

```json
{
  "name": "Rahul",
  "email": "rahul@example.com",
  "age": 20
}
```

### Successful response

```json
{
  "success": true,
  "message": "User created successfully.",
  "data": {
    "id": 2,
    "name": "Rahul",
    "email": "rahul@example.com",
    "age": 20
  }
}
```

### Validation
The API checks:
- name is a string of at least 2 characters
- email has a valid basic email format
- age is an integer from 1 to 120
- duplicate email addresses are rejected

### HTTP status codes
- `200` — successful GET
- `201` — user created
- `400` — invalid input
- `404` — route/user not found
- `409` — duplicate email
- `500` — unexpected server error

## How to run

1. Install Node.js.
2. Open a terminal in this project folder.
3. Run:

```bash
npm install
npm start
```

4. Open `http://localhost:3000`.

For development with automatic restart:

```bash
npm run dev
```

## Testing with curl

Get users:

```bash
curl http://localhost:3000/api/users
```

Create a user:

```bash
curl -X POST http://localhost:3000/api/users   -H "Content-Type: application/json"   -d '{"name":"Rahul","email":"rahul@example.com","age":20}'
```

Get a single user:

```bash
curl http://localhost:3000/api/users/1
```
