const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

let users = [
  { id: 1, name: "Anshpreet", email: "anshpreet@example.com", age: 19 }
];
let nextId = 2;

function validateUser(body) {
  const errors = [];

  if (!body || typeof body !== "object") {
    return ["Request body must be a JSON object."];
  }

  if (typeof body.name !== "string" || body.name.trim().length < 2) {
    errors.push("Name must be a string with at least 2 characters.");
  }

  if (typeof body.email !== "string" || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    errors.push("A valid email is required.");
  }

  if (!Number.isInteger(body.age) || body.age < 1 || body.age > 120) {
    errors.push("Age must be an integer between 1 and 120.");
  }

  return errors;
}

app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "DecodeLabs Project 2 Backend API is running.",
    endpoints: {
      getUsers: "GET /api/users",
      getUser: "GET /api/users/:id",
      createUser: "POST /api/users"
    }
  });
});

app.get("/api/users", (req, res) => {
  res.status(200).json({
    success: true,
    count: users.length,
    data: users
  });
});

app.get("/api/users/:id", (req, res) => {
  const id = Number(req.params.id);

  if (!Number.isInteger(id)) {
    return res.status(400).json({
      success: false,
      message: "User ID must be a valid number."
    });
  }

  const user = users.find((item) => item.id === id);

  if (!user) {
    return res.status(404).json({
      success: false,
      message: "User not found."
    });
  }

  res.status(200).json({
    success: true,
    data: user
  });
});

app.post("/api/users", (req, res) => {
  const errors = validateUser(req.body);

  if (errors.length > 0) {
    return res.status(400).json({
      success: false,
      message: "Validation failed.",
      errors
    });
  }

  const email = req.body.email.trim().toLowerCase();

  if (users.some((user) => user.email === email)) {
    return res.status(409).json({
      success: false,
      message: "A user with this email already exists."
    });
  }

  const newUser = {
    id: nextId++,
    name: req.body.name.trim(),
    email,
    age: req.body.age
  };

  users.push(newUser);

  res.status(201).json({
    success: true,
    message: "User created successfully.",
    data: newUser
  });
});

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found."
  });
});

app.use((err, req, res, next) => {
  if (err instanceof SyntaxError && err.status === 400 && "body" in err) {
    return res.status(400).json({
      success: false,
      message: "Invalid JSON in request body."
    });
  }

  console.error(err);
  res.status(500).json({
    success: false,
    message: "Internal server error."
  });
});

app.listen(PORT, () => {
  console.log(`DecodeLabs API running at http://localhost:${PORT}`);
});
